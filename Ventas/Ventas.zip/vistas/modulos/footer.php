<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 3.0.0
    </div>
    <strong>Copyright &copy; 2025 <a href="#">GRUPO ATLANTIS</a>.</strong> Todos los derechos reservedo
  </footer>