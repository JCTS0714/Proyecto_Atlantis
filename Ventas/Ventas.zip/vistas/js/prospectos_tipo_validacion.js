$(document).ready(function() {
  $('#nuevoTipo').on('change', function() {
    var tipoSeleccionado = $(this).val();
    var documentoInput = $('#nuevoDocumento');

    // Ajustar maxlength y placeholder según tipo seleccionado
    if (tipoSeleccionado === 'DNI') {
      documentoInput.attr('placeholder', 'Ingrese 8 dígitos');
      documentoInput.attr('maxlength', '8');
      documentoInput.removeClass('is-invalid');
    } else if (tipoSeleccionado === 'RUC') {
      documentoInput.attr('placeholder', 'Ingrese 11 dígitos');
      documentoInput.attr('maxlength', '11');
      documentoInput.removeClass('is-invalid');
    } else if (tipoSeleccionado === 'otros') {
      documentoInput.attr('placeholder', 'Ingrese 8 dígitos');
      documentoInput.attr('maxlength', '8');
      documentoInput.removeClass('is-invalid');
    } else {
      documentoInput.attr('placeholder', 'Ingresar documento');
      documentoInput.removeAttr('maxlength');
      documentoInput.removeClass('is-invalid');
    }
  });

  // Validación al enviar el formulario
  $('form[role="form"]').on('submit', function(e) {
    var tipoSeleccionado = $('#nuevoTipo').val();
    var documentoVal = $('#nuevoDocumento').val();

    var regexDNI = /^\d{8}$/;
    var regexRUC = /^\d{11}$/;
    var regexOtros = /^\d{8}$/;

    if (tipoSeleccionado === 'DNI') {
      if (!regexDNI.test(documentoVal)) {
        e.preventDefault();
        $('#nuevoDocumento').addClass('is-invalid');
        alert('El documento debe tener exactamente 8 dígitos numéricos para DNI.');
      } else {
        $('#nuevoDocumento').removeClass('is-invalid');
      }
    } else if (tipoSeleccionado === 'RUC') {
      if (!regexRUC.test(documentoVal)) {
        e.preventDefault();
        $('#nuevoDocumento').addClass('is-invalid');
        alert('El documento debe tener exactamente 11 dígitos numéricos para RUC.');
      } else {
        $('#nuevoDocumento').removeClass('is-invalid');
      }
    } else if (tipoSeleccionado === 'otros') {
      if (!regexOtros.test(documentoVal)) {
        e.preventDefault();
        $('#nuevoDocumento').addClass('is-invalid');
        alert('El documento debe tener exactamente 8 dígitos numéricos para otros.');
      } else {
        $('#nuevoDocumento').removeClass('is-invalid');
      }
    }
  });
});
