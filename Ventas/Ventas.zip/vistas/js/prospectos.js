// prospectos.js
// Stub file to avoid 404 / unexpected HTML being loaded as JS.
// Add prospectos-specific client code here if needed.

(function(){
  // No-op for now
})();
