<?php
// Productos removed — return empty dataset to keep datatable working without producto endpoints
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['data' => []]);

