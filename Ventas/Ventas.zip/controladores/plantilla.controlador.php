<?php
/**CLASE PLANTILLA */
class ControladorPlantilla{
    
    /**Método para Mostrar la Plantilla */
    public function ctrPlantilla(){
        include "vistas/plantilla.php";
    }
}