<?php
class ControladorCliente {

    /** MÉTODO PARA REGISTRAR UN NUEVO CLIENTE */
    static public function ctrCrearCliente() {
        if (isset($_POST["nuevoNombre"])) {
            // Agregar log para depuración
            error_log("Datos recibidos en ctrCrearCliente: " . print_r($_POST, true));
            error_log("Validando campos obligatorios para registrar cliente/prospecto: nombre, tipo, documento, telefono, fecha_contacto, empresa");

            // Log visible para depuración en pantalla
            echo '<pre style="background:#f8d7da; color:#721c24; padding:10px; border-radius:5px; font-family: monospace;">';
            echo "Datos recibidos en ctrCrearCliente:\n";
            print_r($_POST);
            echo "\nValidando campos obligatorios para registrar cliente/prospecto: nombre, tipo, documento, telefono, fecha_contacto, empresa\n";
            echo '</pre>';

            $tipo = $_POST["nuevoTipo"];
            $documento = $_POST["nuevoDocumento"];
            $documentoValido = false;

            if ($tipo === "DNI" && preg_match('/^[0-9]{8}$/', $documento)) {
                $documentoValido = true;
            } elseif ($tipo === "RUC" && preg_match('/^[0-9]{11}$/', $documento)) {
                $documentoValido = true;
            }

            // Ajustar validaciones para permitir espacios y caracteres comunes en nombre y empresa
            if (
                preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ\s\.\-]+$/u', $_POST["nuevoNombre"]) &&
                in_array($tipo, ["DNI", "RUC"]) &&
                $documentoValido &&
                (empty($_POST["nuevoCorreo"]) || filter_var($_POST["nuevoCorreo"], FILTER_VALIDATE_EMAIL)) &&
                preg_match('/^[0-9]{9}$/', $_POST["nuevoTelefono"]) &&
                (empty($_POST["nuevoCiudad"]) || preg_match('/^[\p{L}\p{N}\s\.,#\-]+$/u', $_POST["nuevoCiudad"])) &&
                (empty($_POST["nuevoMigracion"]) || preg_match('/^[\p{L}\p{N}\s\.,#\-]+$/u', $_POST["nuevoMigracion"])) &&
                (empty($_POST["nuevoReferencia"]) || preg_match('/^[\p{L}\p{N}\s\.,#\-]+$/u', $_POST["nuevoReferencia"])) &&
                preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST["nuevoFechaContacto"]) &&
                preg_match('/^[\p{L}\p{N}\s\.\-]+$/u', $_POST["nuevoEmpresa"])
            ) {
                $tabla = "clientes";
                $datos = array(
                    "nombre" => $_POST["nuevoNombre"],
                    "tipo" => $_POST["nuevoTipo"],
                    "documento" => $_POST["nuevoDocumento"],
                    "telefono" => $_POST["nuevoTelefono"],
                    "correo" => $_POST["nuevoCorreo"],
                    "ciudad" => $_POST["nuevoCiudad"],
                    "migracion" => $_POST["nuevoMigracion"],
                    "referencia" => $_POST["nuevoReferencia"],
                    "fecha_contacto" => $_POST["nuevoFechaContacto"],
                    "empresa" => $_POST["nuevoEmpresa"],
                    "estado" => 0
                );

                $respuesta = ModeloCliente::mdlRegistrarCliente($tabla, $datos);

                if ($respuesta == "ok") {
                    $ruta = isset($_POST['ruta']) ? $_POST['ruta'] : 'clientes';
                    if (!isset($_POST['ruta'])) {
                        $referer = $_SERVER['HTTP_REFERER'] ?? '';
                        if (strpos($referer, 'prospectos.php') !== false) {
                            $ruta = 'prospectos';
                        }
                    }
                    echo '<script>
                        swal.fire({
                            icon: "success",
                            title: "¡El prospecto ha sido registrado correctamente!",
                            showConfirmButton: true,
                            confirmButtonText: "Cerrar",
                            showCloseButton: true
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location = "'.$ruta.'";
                            }
                        });
                    </script>';
                } else {
                    $ruta = isset($_POST['ruta']) ? $_POST['ruta'] : 'clientes';
                    if (!isset($_POST['ruta'])) {
                        $referer = $_SERVER['HTTP_REFERER'] ?? '';
                        if (strpos($referer, 'prospectos.php') !== false) {
                            $ruta = 'prospectos';
                        }
                    }
                    echo '<script>
                        swal.fire({
                            icon: "error",
                            title: "¡Error al registrar el prospecto!",
                            showConfirmButton: true,
                            confirmButtonText: "Cerrar",
                            showCloseButton: true
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location = "'.$ruta.'";
                            }
                        });
                    </script>';
                }
            } else {
                $ruta = isset($_POST['ruta']) ? $_POST['ruta'] : 'clientes';
                if (!isset($_POST['ruta'])) {
                    $referer = $_SERVER['HTTP_REFERER'] ?? '';
                    if (strpos($referer, 'prospectos.php') !== false) {
                        $ruta = 'prospectos';
                    }
                }
                echo '<script>
                    swal.fire({
                        icon: "error",
                        title: "¡Los campos tienen errores o están vacíos!",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar",
                        showCloseButton: true
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location = "'.$ruta.'";
                        }
                    });
                </script>';
            }
        }
    }

    /**============================
     * MÉTODO PARA MOSTRAR CLIENTE
     * ============================ */
    static public function ctrMostrarCliente($item, $valor) {
        $tabla = "clientes";
        $respuesta = ModeloCliente::MdlMostrarCliente($tabla, $item, $valor);
        return $respuesta;
    }

    /**============================
     * NUEVO MÉTODO PARA MOSTRAR CLIENTE POR ID
     * ============================ */
    static public function ctrMostrarClientePorId($id) {
        $tabla = "clientes";
        $respuesta = ModeloCliente::mdlMostrarCliente($tabla, "id", $id);
        return $respuesta;
    }

    /**============================
     * MÉTODO PARA EDITAR CLIENTE
     * ============================ */
    static public function ctrEditarCliente(){
        if(isset($_POST["editarNombre"])){
            $tabla = "clientes";
            $datos = array(
                "id" => $_POST["idCliente"],
                "nombre" => $_POST["editarNombre"],
                "tipo" => $_POST["editarTipo"],
                "documento" => $_POST["editarDocumento"],
                "telefono" => $_POST["editarTelefono"],
                "correo" => $_POST["editarCorreo"],
                "ciudad" => $_POST["editarCiudad"],
                "migracion" => $_POST["editarMigracion"],
                "referencia" => $_POST["editarReferencia"],
                "fecha_contacto" => $_POST["editarFechaContacto"],
                "empresa" => $_POST["editarEmpresa"]
                //"fecha_creacion" => $_POST["editarFechaCreacion"]
            );
            if (!preg_match('/^[0-9]{9}$/', $_POST["editarTelefono"])) {
                echo '<script>
                    Swal.fire({
                        icon: "error",
                        title: "¡El teléfono debe tener exactamente 9 dígitos!",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar"
                    });
                </script>';
                return;
            }
            $respuesta = ModeloCliente::mdlEditarCliente($tabla, $datos);

            if($respuesta == "ok"){
                $ruta = isset($_POST['ruta']) ? $_POST['ruta'] : 'clientes';
                if (!isset($_POST['ruta'])) {
                    $referer = $_SERVER['HTTP_REFERER'] ?? '';
                    if (strpos($referer, 'prospectos.php') !== false) {
                        $ruta = 'prospectos';
                    }
                }
                echo '<script>
                    Swal.fire({
                        icon: "success",
                        title: "¡El cliente ha sido editado correctamente!",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar"
                    }).then((result) => {
                        if(result.isConfirmed){
                            window.location = "'.$ruta.'";
                        }
                    });
                </script>';
            } else {
                echo '<script>
                    Swal.fire({
                        icon: "error",
                        title: "¡Error al editar el cliente!",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar"
                    });
                </script>';
            }
        }
    }
    /**============================
     * MÉTODO PARA MOSTRAR CLIENTES PARA OPORTUNIDAD
     * ============================
     */
    static public function ctrMostrarClientesParaOportunidad($searchTerm = null) {
        $tabla = "clientes";
        $respuesta = ModeloCliente::mdlMostrarClientesParaOportunidad($searchTerm);
        return $respuesta;
    }

    //**METODO PARA ELIMINAR CLIENTE */
    static public function ctrEliminarCliente(){
        if(isset($_GET["idClienteEliminar"])){

            // Verificar permisos: solo Administrador puede eliminar clientes
            if($_SESSION["perfil"] == "Vendedor"){

              echo '<script>

                Swal.fire({

                  icon: "error",

                  title: "¡No tienes permisos para eliminar clientes!",

                  showConfirmButton: true,

                  confirmButtonText: "Cerrar",

                  showCloseButton: true

                }).then((result)=>{

                  if(result.isConfirmed){

                    window.location = "clientes";

                  }

                });

              </script>';

              return;

            }

            $tabla = "clientes";
            $datos = $_GET["idClienteEliminar"];
            $ruta = isset($_GET['ruta']) ? $_GET['ruta'] : 'clientes';

            // Verificar si el cliente tiene oportunidades asociadas antes de eliminar
            $tieneOportunidades = ModeloCliente::mdlVerificarOportunidades($datos);
            if ($tieneOportunidades) {
                echo '<script>
                    Swal.fire({
                        icon: "error",
                        title: "¡No se puede eliminar el cliente porque tiene oportunidades asociadas! Primero elimine las oportunidades.",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar"
                    }).then((result) => {
                        if(result.isConfirmed){
                            window.location = "'.$ruta.'";
                        }
                    });
                </script>';
                return;
            }

            $respuesta = ModeloCliente::mdlEliminarCliente($tabla, $datos);
            if($respuesta == "ok"){
                echo '<script>
                    Swal.fire({
                        icon: "success",
                        title: "¡El cliente ha sido eliminado correctamente!",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar"
                    }).then((result) => {
                        if(result.isConfirmed){
                            window.location = "'.$ruta.'";
                        }
                    });
                </script>';
            } else {
                echo '<script>
                    Swal.fire({
                        icon: "error",
                        title: "¡Error al eliminar el cliente!",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar"
                    });
                </script>';
            }
        }
    }
}
