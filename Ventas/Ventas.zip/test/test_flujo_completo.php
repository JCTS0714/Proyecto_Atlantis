<?php
/**
 * Test script to verify the meeting verification functionality
 * Tests the ctrVerificarReunionExistente method with existing data
 */

require_once __DIR__ . '/../controladores/ControladorOportunidad.php';
require_once __DIR__ . '/../modelos/ModeloCRM.php';

echo "=== Testing Meeting Verification with Existing Data ===\n\n";

// First, let's check what meetings exist in the database
echo "Step 1: Checking existing meetings in database...\n";

try {
    require_once __DIR__ . '/../modelos/conexion.php';
    $stmt = Conexion::conectar()->prepare("SELECT r.*, c.nombre as nombre_cliente FROM reuniones r LEFT JOIN clientes c ON r.cliente_id = c.id LIMIT 5");
    $stmt->execute();
    $existingMeetings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo "Found " . count($existingMeetings) . " meetings in database:\n";
    foreach ($existingMeetings as $meeting) {
        echo "- ID: {$meeting['id']}, Cliente: {$meeting['nombre_cliente']} (ID: {$meeting['cliente_id']}), Título: {$meeting['titulo']}, Fecha: {$meeting['fecha']}\n";
    }
    echo "\n";

    if (empty($existingMeetings)) {
        echo "❌ No existing meetings found. Testing with simulated scenarios...\n\n";

        // Test with non-existent data (should return false)
        $testCases = [
            [
                'cliente_id' => 1,
                'actividad' => 'reunion',
                'fecha' => '2024-12-15',
                'expected' => false,
                'description' => 'Non-existent meeting (no data in DB)'
            ],
            [
                'cliente_id' => 999,
                'actividad' => 'llamada',
                'fecha' => '2024-12-20',
                'expected' => false,
                'description' => 'Non-existent client and meeting'
            ]
        ];
    } else {
        // Test with existing data
        $firstMeeting = $existingMeetings[0];
        $testCases = [
            [
                'cliente_id' => $firstMeeting['cliente_id'],
                'actividad' => 'reunion', // Assuming this maps to the existing meeting title
                'fecha' => $firstMeeting['fecha'],
                'expected' => true,
                'description' => 'Should find existing meeting with matching criteria'
            ],
            [
                'cliente_id' => $firstMeeting['cliente_id'],
                'actividad' => 'llamada', // Different activity
                'fecha' => $firstMeeting['fecha'],
                'expected' => false,
                'description' => 'Should NOT find meeting with different activity mapping'
            ],
            [
                'cliente_id' => $firstMeeting['cliente_id'],
                'actividad' => 'reunion',
                'fecha' => '2024-12-31', // Different date
                'expected' => false,
                'description' => 'Should NOT find meeting with different date'
            ]
        ];
    }

} catch (Exception $e) {
    echo "❌ Error checking existing meetings: " . $e->getMessage() . "\n";
    exit(1);
}

echo "Step 2: Testing meeting verification logic...\n\n";

foreach ($testCases as $i => $test) {
    echo "Test " . ($i + 1) . ": " . $test['description'] . "\n";
    echo "Input: cliente_id=" . $test['cliente_id'] . ", actividad='" . $test['actividad'] . "', fecha='" . $test['fecha'] . "'\n";

    try {
        $result = ControladorOportunidad::ctrVerificarReunionExistente(
            $test['cliente_id'],
            $test['actividad'],
            $test['fecha']
        );

        $status = ($result === $test['expected']) ? '✅ PASS' : '❌ FAIL';
        echo "Result: " . ($result ? 'true' : 'false') . " (expected: " . ($test['expected'] ? 'true' : 'false') . ") - $status\n";

        // Show what title was actually searched for
        $mappedTitle = ControladorOportunidad::testMapearActividadATitulo($test['actividad']);
        echo "Mapped title searched: '$mappedTitle'\n";

    } catch (Exception $e) {
        echo "❌ EXCEPTION: " . $e->getMessage() . "\n";
    }

    echo "\n" . str_repeat("-", 50) . "\n\n";
}

echo "Step 3: Testing activity mapping function...\n\n";

$mappingTests = [
    'reunion' => 'Reunión',
    'llamada' => 'Llamada',
    'mensaje de whatsapp' => 'Mensaje WhatsApp',
    'seguimiento de presupuesto' => 'Seguimiento de Presupuesto',
    'ofertar' => 'Ofertar',
    'llamada para demostracion' => 'Llamada para Demostración',
    'otros' => 'Otros'
];

echo "Activity to Title Mapping:\n";
foreach ($mappingTests as $activity => $expectedTitle) {
    $actualTitle = ControladorOportunidad::testMapearActividadATitulo($activity);
    $status = ($actualTitle === $expectedTitle) ? '✅' : '❌';
    echo "$status '$activity' → '$actualTitle' (expected: '$expectedTitle')\n";
}

echo "\n=== Test Complete ===\n";

if (!empty($existingMeetings)) {
    echo "\n💡 Recommendation: The verification logic is working correctly.\n";
    echo "   If you're still experiencing issues, check:\n";
    echo "   1. The activity values in your opportunity form\n";
    echo "   2. The date format being sent from frontend\n";
    echo "   3. Whether the meetings in DB have the expected titles\n";
} else {
    echo "\n💡 Note: No meetings exist in database, so verification always returns false.\n";
    echo "   This is expected behavior when no data matches the criteria.\n";
}
?>
