<?php
/**
 * Test script to verify meeting creation functionality
 * This script tests the opportunity update flow with meeting creation
 */

require_once __DIR__ . '/../controladores/ControladorOportunidad.php';
require_once __DIR__ . '/../modelos/ModeloCRM.php';

echo "=== Testing Meeting Creation Functionality ===\n\n";

// Test data
$testData = [
    'id' => 1, // Assuming opportunity with ID 1 exists
    'titulo' => 'Test Opportunity with Meeting',
    'descripcion' => 'Testing meeting creation functionality',
    'valor_estimado' => 5000.00,
    'probabilidad' => 75,
    'fecha_cierre_estimada' => '2024-12-31',
    'actividad' => 'reunion',
    'fecha_actividad' => '2024-12-15',
    'cliente_id' => 1, // Assuming client with ID 1 exists
    'usuario_id' => 1  // Assuming user with ID 1 exists
];

echo "Test Data:\n";
echo json_encode($testData, JSON_PRETTY_PRINT) . "\n\n";

echo "Testing ctrActualizarOportunidad()...\n";

try {
    $result = ControladorOportunidad::ctrActualizarOportunidad($testData);

    echo "Controller Result: " . $result . "\n";

    if ($result === 'ok') {
        echo "✅ SUCCESS: Opportunity updated successfully\n";
        echo "✅ Meeting should have been created\n";
    } else {
        echo "❌ ERROR: " . $result . "\n";
    }

} catch (Exception $e) {
    echo "❌ EXCEPTION: " . $e->getMessage() . "\n";
}

echo "\n=== Test Complete ===\n";

// Test with missing date
echo "\n=== Testing with missing date ===\n";

$testDataIncomplete = $testData;
$testDataIncomplete['fecha_actividad'] = '';

echo "Test Data (missing date):\n";
echo json_encode($testDataIncomplete, JSON_PRETTY_PRINT) . "\n\n";

try {
    $result = ControladorOportunidad::ctrActualizarOportunidad($testDataIncomplete);

    echo "Controller Result: " . $result . "\n";

    if ($result === 'ok') {
        echo "✅ SUCCESS: Opportunity updated (no meeting created due to missing date)\n";
    } else {
        echo "❌ ERROR: " . $result . "\n";
    }

} catch (Exception $e) {
    echo "❌ EXCEPTION: " . $e->getMessage() . "\n";
}

echo "\n=== Test Complete ===\n";
?>
