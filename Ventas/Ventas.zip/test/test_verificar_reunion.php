<?php
/**
 * Test script to verify the meeting verification functionality
 * Tests the ctrVerificarReunionExistente method
 */

require_once __DIR__ . '/../controladores/ControladorOportunidad.php';

echo "=== Testing Meeting Verification Functionality ===\n\n";

// Test cases
$testCases = [
    [
        'cliente_id' => 1,
        'actividad' => 'reunion',
        'fecha' => '2024-12-15',
        'description' => 'Test with valid data - should work with mapping'
    ],
    [
        'cliente_id' => 1,
        'actividad' => 'llamada',
        'fecha' => '2024-12-15',
        'description' => 'Test with different activity - should map to "Llamada"'
    ],
    [
        'cliente_id' => 1,
        'actividad' => 'mensaje de whatsapp',
        'fecha' => '2024-12-15',
        'description' => 'Test with WhatsApp message - should map correctly'
    ],
    [
        'cliente_id' => 999,
        'actividad' => 'reunion',
        'fecha' => '2024-12-15',
        'description' => 'Test with non-existent client - should return false'
    ],
    [
        'cliente_id' => 1,
        'actividad' => 'reunion',
        'fecha' => '2024-12-31',
        'description' => 'Test with different date - should return false'
    ]
];

foreach ($testCases as $i => $testCase) {
    echo "Test Case " . ($i + 1) . ": " . $testCase['description'] . "\n";
    echo "Input: cliente_id=" . $testCase['cliente_id'] . ", actividad='" . $testCase['actividad'] . "', fecha='" . $testCase['fecha'] . "'\n";

    try {
        $result = ControladorOportunidad::ctrVerificarReunionExistente(
            $testCase['cliente_id'],
            $testCase['actividad'],
            $testCase['fecha']
        );

        echo "Result: " . ($result ? 'true' : 'false') . "\n";

        if ($result) {
            echo "✅ Meeting exists for this client/date\n";
        } else {
            echo "❌ No meeting found for this client/date\n";
        }

    } catch (Exception $e) {
        echo "❌ EXCEPTION: " . $e->getMessage() . "\n";
    }

    echo "\n" . str_repeat("-", 50) . "\n\n";
}

// Test the mapping function directly
echo "=== Testing Activity Mapping Function ===\n\n";

$mappingTests = [
    'llamada' => 'Llamada',
    'reunion' => 'Reunión',
    'mensaje de whatsapp' => 'Mensaje WhatsApp',
    'seguimiento de presupuesto' => 'Seguimiento de Presupuesto',
    'ofertar' => 'Ofertar',
    'llamada para demostracion' => 'Llamada para Demostración',
    'otros' => 'Otros',
    'unknown_activity' => 'unknown_activity' // Should return as-is
];

foreach ($mappingTests as $input => $expected) {
    $result = ControladorOportunidad::testMapearActividadATitulo($input);
    $status = ($result === $expected) ? '✅' : '❌';
    echo "$status '$input' -> '$result' (expected: '$expected')\n";
}

echo "\n=== Test Complete ===\n";
?>
