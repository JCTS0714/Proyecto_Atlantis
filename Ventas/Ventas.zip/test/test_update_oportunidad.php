<?php
require_once '../controladores/ControladorOportunidad.php';
require_once '../modelos/ModeloCRM.php';

header('Content-Type: application/json');

// Test data for update
$datos = array(
    "id" => 1, // Assuming an opportunity with id 1 exists
    "titulo" => "Oportunidad Actualizada",
    "descripcion" => "Descripción actualizada",
    "valor_estimado" => "50000",
    "probabilidad" => 75,
    "fecha_cierre_estimada" => "2024-12-31"
);

$result = ControladorOportunidad::ctrActualizarOportunidad($datos);
echo json_encode(array("result" => $result));
?>
