<?php
return [
    'APP_ENV' => 'local',
    'FORCE_HTTP' => true,
    'BASE_HOST' => 'localhost',
    'display_errors' => true,
    'error_reporting' => E_ALL,
    'FORCE_RELOAD_ON_UPDATE' => true,
];
