<?php
// Test para inicio de sesión con "Recordarme" para usuario id=28, usuario=juan, password=1234

require_once "../controladores/usuarios.controlador.php";
require_once "../modelos/usuarios.modelo.php";
require_once "../modelos/conexion.php";

$_POST["ingUsuario"] = "juan";
$_POST["ingPassword"] = "1234";
$_POST["remember_me"] = "on";

$controlador = new ControladorUsuarios();
$controlador->ctrIngresoUsuario();

// Verificar si la cookie remember_token se ha seteado
if (isset($_COOKIE["remember_token"])) {
    echo "Cookie remember_token seteada correctamente: " . $_COOKIE["remember_token"] . "\n";
} else {
    echo "Cookie remember_token NO fue seteada.\n";
}

// Verificar si la sesión se inició
session_start();
if (isset($_SESSION["iniciarSesion"]) && $_SESSION["iniciarSesion"] == "ok") {
    echo "Sesión iniciada correctamente para el usuario: " . $_SESSION["usuario"] . "\n";
} else {
    echo "Sesión NO iniciada.\n";
}
?>
