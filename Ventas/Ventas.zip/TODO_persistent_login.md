# Implementación de Inicio de Sesión Persistente

## Estado: COMPLETADO ✅

### Resumen
Se ha implementado el método de inicio de sesión persistente que permite mantener la sesión activa incluso después de cerrar y volver a abrir el navegador.

### Componentes Implementados

#### 1. Modelo de Usuarios (usuarios.modelo.php)
- ✅ Método `mdlActualizarRememberToken($id, $remember_token, $remember_expires)`: Actualiza el token de recuerdo y fecha de expiración en la base de datos.
- ✅ Método `mdlMostrarUsuarioPorRememberToken($remember_token)`: Obtiene usuario por token de recuerdo si no ha expirado.

#### 2. Controlador de Usuarios (usuarios.controlador.php)
- ✅ Lógica en `ctrIngresoUsuario()`: Al iniciar sesión, si se marca "Recordarme", genera un token único, lo guarda en BD con expiración de 30 días y establece una cookie persistente.

#### 3. Vista de Login (login.php)
- ✅ Checkbox "Recordarme" agregado al formulario de login.

#### 4. Plantilla (plantilla.php)
- ✅ Verificación automática de cookie `remember_token` al cargar la página.
- ✅ Restauración de sesión si el token es válido y no expirado.
- ✅ Eliminación de cookie si el token es inválido.

#### 5. Base de Datos
- ✅ Columnas `remember_token` (VARCHAR) y `remember_expires` (DATETIME) en tabla `usuarios`.

### Funcionamiento
1. Usuario marca "Recordarme" al iniciar sesión.
2. Se genera un token único y se guarda en BD con expiración (30 días).
3. Se establece una cookie `remember_token` en el navegador.
4. Al cerrar y abrir el navegador, la cookie persiste.
5. Al cargar la página, se verifica la cookie y se restaura la sesión automáticamente si el token es válido.

### Seguridad
- Tokens únicos generados con `random_bytes(32)`.
- Expiración automática de tokens después de 30 días.
- Validación de tokens en BD para prevenir manipulación.
- Regeneración de ID de sesión al restaurar.

### Pruebas
- Verificar que al marcar "Recordarme" se mantenga la sesión tras cerrar el navegador.
- Verificar que sin marcar "Recordarme" la sesión expire al cerrar el navegador.
- Verificar expiración automática de tokens.
