# TODO - Implementación de Destacado de Actividades en Calendario

## Tareas Completadas

### 1. Modificación de calendario.js
- [x] Agregar `eventRender` en la configuración de FullCalendar para asignar `data-cliente_id` a cada evento.
- [x] Implementar función `destacarActividad(actividad, clienteId)` que:
  - Quita resaltado previo de todos los eventos.
  - Busca eventos que coincidan con la actividad y cliente_id.
  - Agrega clase 'actividad-destacada' a los eventos coincidentes.
- [x] Agregar event listener para botones con clase '.actividad-btn' que llama a `destacarActividad` con los datos del botón.
- [x] Agregar event listener global para quitar resaltado al hacer clic fuera de eventos del calendario y botones de actividad.

### 2. Modificación de calendario.php
- [x] Agregar estilos CSS para la clase '.actividad-destacada':
  - Borde rojo de 3px.
  - Sombra con efecto de resplandor rojo.

### 3. Verificación de Dependencias
- [x] Confirmar que el método `mdlMostrarReunionesPorClientes` existe en `ModeloCalendario`.
- [x] Verificar que los botones de actividad en la lista de clientes tienen los atributos `data-actividad` y `data-cliente-id`.

## Funcionalidad Implementada
- Los usuarios pueden hacer clic en los botones de actividades en la lista de "Clientes Recientes".
- Al hacer clic, los eventos correspondientes en el calendario se resaltan con un borde rojo y sombra.
- El resaltado se quita automáticamente al seleccionar otra actividad.

## Notas
- La funcionalidad utiliza jQuery y FullCalendar para manipular los eventos del calendario.
- Los estilos CSS se aplican directamente en el archivo calendario.php para simplicidad.
- No se requieren cambios en el backend, ya que la lógica se maneja en el frontend.
