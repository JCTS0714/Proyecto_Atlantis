<?php
require_once __DIR__ . '/modelos/conexion.php';
require_once __DIR__ . '/config/estados.php';

header('Content-Type: text/plain');

try {
    $conexion = Conexion::conectar();
    
    echo "=== CREANDO DATOS DE PRUEBA PARA ZONA DE ESPERA ===\n\n";
    
    // Primero, verificar si hay algún cliente disponible
    $stmt = $conexion->query("SELECT id, nombre FROM clientes LIMIT 5");
    $clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($clientes)) {
        echo "❌ No hay clientes disponibles. Necesitas crear clientes primero.\n";
        exit;
    }
    
    echo "Clientes disponibles:\n";
    foreach ($clientes as $cliente) {
        echo "- ID: {$cliente['id']}, Nombre: {$cliente['nombre']}\n";
    }
    
    // Crear algunas oportunidades en estado 4 (Zona de Espera)
    // Usar el usuario ID 27 (jean) que existe en la base de datos
    $oportunidades = [
        [
            'cliente_id' => $clientes[0]['id'],
            'usuario_id' => 27, // Usuario válido: jean
            'titulo' => 'Prueba Zona Espera 1',
            'descripcion' => 'Oportunidad de prueba para zona de espera',
            'valor_estimado' => 1000,
            'probabilidad' => 50,
            'estado' => ESTADO_EN_ESPERA,
            'fecha_cierre_estimada' => date('Y-m-d', strtotime('+30 days'))
        ],
        [
            'cliente_id' => $clientes[1]['id'],
            'usuario_id' => 27,
            'titulo' => 'Prueba Zona Espera 2',
            'descripcion' => 'Segunda oportunidad de prueba',
            'valor_estimado' => 2500,
            'probabilidad' => 30,
            'estado' => ESTADO_EN_ESPERA,
            'fecha_cierre_estimada' => date('Y-m-d', strtotime('+45 days'))
        ],
        [
            'cliente_id' => $clientes[2]['id'],
            'usuario_id' => 27,
            'titulo' => 'Prueba Zona Espera 3',
            'descripcion' => 'Tercera oportunidad de prueba',
            'valor_estimado' => 5000,
            'probabilidad' => 20,
            'estado' => ESTADO_EN_ESPERA,
            'fecha_cierre_estimada' => date('Y-m-d', strtotime('+60 days'))
        ]
    ];
    
    $insertados = 0;
    foreach ($oportunidades as $oportunidad) {
        $stmt = $conexion->prepare("
            INSERT INTO oportunidades 
            (cliente_id, usuario_id, titulo, descripcion, valor_estimado, probabilidad, estado, fecha_cierre_estimada, fecha_modificacion)
            VALUES (:cliente_id, :usuario_id, :titulo, :descripcion, :valor_estimado, :probabilidad, :estado, :fecha_cierre_estimada, NOW())
        ");
        
        $stmt->bindParam(':cliente_id', $oportunidad['cliente_id']);
        $stmt->bindParam(':usuario_id', $oportunidad['usuario_id']);
        $stmt->bindParam(':titulo', $oportunidad['titulo']);
        $stmt->bindParam(':descripcion', $oportunidad['descripcion']);
        $stmt->bindParam(':valor_estimado', $oportunidad['valor_estimado']);
        $stmt->bindParam(':probabilidad', $oportunidad['probabilidad']);
        $stmt->bindParam(':estado', $oportunidad['estado']);
        $stmt->bindParam(':fecha_cierre_estimada', $oportunidad['fecha_cierre_estimada']);
        
        if ($stmt->execute()) {
            $insertados++;
            echo "✅ Oportunidad '{$oportunidad['titulo']}' creada exitosamente\n";
        } else {
            echo "❌ Error al crear oportunidad '{$oportunidad['titulo']}'\n";
        }
    }
    
    echo "\n=== RESULTADO ===\n";
    echo "Oportunidades creadas en zona de espera: $insertados de " . count($oportunidades) . "\n";
    
    // Verificar que los datos se crearon correctamente
    $stmt = $conexion->query("SELECT COUNT(*) as total FROM oportunidades WHERE estado = " . ESTADO_EN_ESPERA);
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "Total de registros en zona de espera después de la inserción: " . $resultado['total'] . "\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
