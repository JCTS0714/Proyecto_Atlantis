<?php
/**
 * Script simple para probar la sesión persistente
 */

session_start();

// Verificar si hay sesión activa
if (isset($_SESSION["iniciarSesion"]) && $_SESSION["iniciarSesion"] == "ok") {
    echo "<h1>Sesión Activa</h1>";
    echo "<p>Usuario: " . $_SESSION["usuario"] . "</p>";
    echo "<p>Nombre: " . $_SESSION["nombre"] . "</p>";
    echo "<p>Perfil: " . $_SESSION["perfil"] . "</p>";
    echo "<p>ID de sesión: " . session_id() . "</p>";
    echo "<p>Token de sesión: " . $_SESSION["sesion_token"] . "</p>";

    // Mostrar información de la cookie de sesión
    if (isset($_COOKIE[session_name()])) {
        echo "<p>Cookie de sesión existe: " . $_COOKIE[session_name()] . "</p>";
    } else {
        echo "<p style='color: red;'>No hay cookie de sesión</p>";
    }

    echo "<p><a href='?logout=1'>Cerrar sesión</a></p>";
} else {
    echo "<h1>No hay sesión activa</h1>";
    echo "<p>ID de sesión actual: " . session_id() . "</p>";
    echo "<p><a href='index.php'>Ir al login</a></p>";
}

// Manejar logout
if (isset($_GET["logout"])) {
    session_destroy();
    echo "<script>window.location = 'test_simple_session.php';</script>";
}
?>
