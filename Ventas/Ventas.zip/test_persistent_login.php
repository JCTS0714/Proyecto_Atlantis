<?php
require_once "modelos/conexion.php";
require_once "modelos/usuarios.modelo.php";

// Obtener un usuario existente para pruebas
$tabla = "usuarios";
$item = "estado";
$valor = 1; // Usuarios activos

$usuarios = ModeloUsuarios::MdlMostrarUsuarios($tabla, $item, $valor);

if ($usuarios && is_array($usuarios)) {
    $respuesta = $usuarios; // Es una sola fila
    echo "Usuario encontrado: " . $respuesta["usuario"] . "\n";

    // Generar token de recuerdo
    $remember_token = bin2hex(random_bytes(32));
    $remember_expires = date('Y-m-d H:i:s', strtotime('+30 days'));

    $resultado = ModeloUsuarios::mdlActualizarRememberToken($respuesta["id"], $remember_token, $remember_expires);

    if ($resultado == "ok") {
        echo "Token de recuerdo guardado en BD.\n";
        echo "Token: $remember_token\n";
        echo "Expira: $remember_expires\n";

        // Simular setcookie
        echo "Cookie debería ser: remember_token = $remember_token, path=/, expires=" . (time() + (30 * 24 * 60 * 60)) . "\n";
    } else {
        echo "Error al guardar token.\n";
    }
} else {
    echo "No se encontraron usuarios activos.\n";
}

// Simular verificación de token
echo "\n--- Verificación de token ---\n";
$token_a_verificar = $remember_token; // Usar el token generado
$usuario_verificado = ModeloUsuarios::mdlMostrarUsuarioPorRememberToken($token_a_verificar);

if ($usuario_verificado) {
    echo "Token válido. Usuario: " . $usuario_verificado["usuario"] . "\n";
} else {
    echo "Token inválido o expirado.\n";
}
?>
