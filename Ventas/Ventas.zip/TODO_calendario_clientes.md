# TODO: Modificar lista de clientes recientes en calendario.php

## Pasos a completar:

1. **Agregar método en modelo para obtener reuniones por múltiples clientes**
   - Archivo: Ventas/modelos/calendario.modelo.php
   - Método: mdlMostrarReunionesPorClientes($clienteIds)
   - Consulta SQL para obtener reuniones de una lista de cliente_ids

2. **Modificar calendario.php para mostrar actividades en lugar de email**
   - Archivo: Ventas/Vistas/modulos/calendario.php
   - Obtener ids de clientes recientes
   - Consultar reuniones usando el nuevo método
   - Agrupar reuniones por cliente
   - Mostrar títulos de reuniones separados por "-" si hay múltiples
   - Si no hay reuniones, mostrar "Sin actividades"

3. **Probar los cambios**
   - Verificar que la lista muestre correctamente las actividades
   - Asegurar que no haya errores en la carga de la página
   - Confirmar que el rendimiento no se vea afectado

## Estado actual:
- [ ] Paso 1: Agregar método en modelo
- [ ] Paso 2: Modificar vista calendario.php
- [ ] Paso 3: Probar cambios
