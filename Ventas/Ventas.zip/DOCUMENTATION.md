# Proyecto Atlantis - Sistema de Gestión de Ventas

## Descripción General
Proyecto Atlantis es una aplicación web para la gestión de ventas y CRM (Customer Relationship Management) desarrollada en PHP con arquitectura MVC. Permite administrar clientes, prospectos, ventas, calendario de reuniones y generar reportes con dashboards interactivos.

## Tecnologías Utilizadas

### Backend
- **PHP**: Versión 7+ (utiliza PDO para conexiones a base de datos)
- **Base de Datos**: MySQL con charset utf8mb4
  - Host: localhost
  - Base de datos: atlantisbd
  - Usuario: root
  - Contraseña: (vacía)

### Frontend
- **HTML5** y **CSS3**
- **JavaScript** (ES6+)

### Frameworks y Librerías
- **AdminLTE**: Framework para paneles de administración
- **Bootstrap**: Versión 3.3.7 para diseño responsivo
- **jQuery**: Versión 3 para manipulación DOM y AJAX
- **Chart.js**: Versión 4.4.0 para gráficos interactivos
- **DataTables**: Para tablas dinámicas y paginadas
- **SweetAlert2**: Versión 11 para alertas modales
- **FullCalendar**: Para calendario de eventos
- **Font Awesome**: Iconos
- **Ionicons**: Iconos adicionales

## Arquitectura del Proyecto

### Patrón MVC (Modelo-Vista-Controlador)
- **Modelos** (`modelos/`): Lógica de negocio y acceso a datos
- **Vistas** (`Vistas/`): Plantillas HTML y presentación
- **Controladores** (`controladores/`): Lógica de aplicación y enrutamiento

### Estructura de Directorios
```
/
├── ajax/                 # Handlers AJAX
├── config/               # Archivos de configuración
├── controladores/        # Controladores PHP
├── css/                  # Estilos CSS personalizados
├── docs/                 # Documentación adicional
├── modelos/              # Modelos de datos
├── test/                 # Archivos de prueba
├── Vistas/               # Vistas y assets
│   ├── bower_components/ # Librerías de terceros
│   ├── dist/            # Archivos compilados AdminLTE
│   ├── js/              # JavaScript personalizado
│   ├── modulos/         # Módulos de vistas
│   └── plugins/         # Plugins adicionales
├── index.php            # Punto de entrada
├── .htaccess            # Configuración Apache
└── DOCUMENTATION.md     # Esta documentación
```

## Módulos del Sistema

### Módulos Principales
- **Inicio**: Dashboard con indicadores y gráficos
- **Usuarios**: Gestión de usuarios del sistema
- **Categorías**: Categorización de productos
- **Productos**: Inventario de productos
- **Clientes**: Base de datos de clientes
- **Ventas**: Registro y gestión de ventas
- **Crear Venta**: Formulario para nuevas ventas
- **Reportes**: Generación de reportes
- **Proveedor**: Gestión de proveedores
- **Prospectos**: Potenciales clientes
- **Calendario**: Agenda de reuniones y eventos
- **CRM**: Gestión de relaciones con clientes
- **Seguimiento**: Seguimiento de prospectos
- **No Clientes**: Clientes perdidos
- **Zona Espera**: Prospectos en espera
- **Salir**: Cierre de sesión

## Funcionalidades del Dashboard

### Indicadores Clave
- Clientes ganados (este mes)
- Nuevos prospectos (con variación mensual)
- Clientes perdidos (este mes)
- Reuniones programadas (esta semana)

### Gráficos Interactivos
- **Distribución de Clientes**: Gráfico de dona mostrando prospectos, seguimiento, clientes, no clientes y zona espera
- **Evolución Mensual**: Gráfico de líneas con tendencias de prospectos, seguimiento y clientes
- **Reuniones de la Semana**: Lista de reuniones programadas

### Resumen General
- Total de prospectos
- Total de clientes
- Total de reuniones

## Características Técnicas

### Seguridad
- Validación de sesiones con tokens únicos
- Protección contra accesos no autorizados
- Sanitización de datos de entrada

### Interfaz de Usuario
- Diseño responsivo con Bootstrap
- Tema AdminLTE con skin azul
- Fondo personalizado
- Navegación colapsable

### Funcionalidades AJAX
- Carga dinámica de datos sin recargar página
- Actualización automática cada 5 minutos en dashboard
- Manejo de errores con SweetAlert2

### Base de Datos
- Conexión PDO con manejo de excepciones
- Charset UTF8MB4 para soporte Unicode completo
- Consultas preparadas para prevenir SQL injection

## Instalación y Configuración

1. **Requisitos del Sistema**:
   - Servidor web (Apache/Nginx)
   - PHP 7.0+
   - MySQL 5.7+
   - Extensiones PHP: PDO, mbstring

2. **Configuración de Base de Datos**:
   - Crear base de datos `atlantisbd`
   - Importar esquema de tablas
   - Configurar credenciales en `modelos/conexion.php`

3. **Configuración del Proyecto**:
   - Copiar archivos al directorio web
   - Configurar `.htaccess` para reescritura de URLs
   - Asegurar permisos de escritura en directorios necesarios

4. **Acceso Inicial**:
   - Usuario administrador por defecto
   - Cambiar contraseña después del primer acceso

## Desarrollo y Mantenimiento

### Convenciones de Código
- Nombres de archivos en minúsculas con guiones bajos
- Clases PHP con notación CamelCase
- Funciones con prefijo descriptivo
- Comentarios en español

### Versiones de Librerías
- Todas las librerías están incluidas localmente en `Vistas/bower_components/`
- Chart.js actualizado a CDN para compatibilidad
- jQuery y Bootstrap en versiones estables

### Próximas Mejoras
- Migración a Bootstrap 5
- Implementación de API REST
- Optimización de consultas de base de datos
- Mejora de seguridad con JWT tokens

## Contacto y Soporte
Para soporte técnico o consultas sobre el proyecto, contactar al equipo de desarrollo.

---
*Documentación generada automáticamente - Última actualización: $(date)*
