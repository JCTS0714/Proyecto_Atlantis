ALTER TABLE reuniones
ADD COLUMN ultima_notificacion DATE NULL AFTER evento_id;
